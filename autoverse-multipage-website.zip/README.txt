AUTOVERSE MULTI-PAGE WEBSITE
Upload the contents of this folder (index.html, explore.html, compare.html, brands.html, categories.html, performance.html, popular.html, about.html, and assets folder) to the ROOT of your GitHub repository.
Keep the files in the root, not inside a nested folder.
GitHub Pages publishing source should be main branch / root.

Pages included:
Home, Explore, Compare, Brands, Categories, Performance, Popular, About.\nNote: Catalog figures are sample/illustrative data; verify specifications and prices before using as factual comparisons. Images are loaded from remote image hosts and require internet.
